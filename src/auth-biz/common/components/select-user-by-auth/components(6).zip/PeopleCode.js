// 返回所选中的人员编码及人员姓名编码组件
/** 
 * 传入值
 * @param defaultActiveKey string 初始展开列表 默认为1 打开机构 2为打开角色
 * @param keys array 初始选中值 格式为
 * keys={[
        {
            userCode: "zjtest002",
            userName: "zjtest002测试",
        },
    ]}
    keys中的参数可以溢出 但是必须含有指定的key和name的命名 默认：userCode和userName两个字段
 *  @param keyNames array 指定键值对的命名(返回值也会变成该命名) 指定键值对命名时keys也要改成对应命名传入
 *  keyNames={{'key': 'aaa','name': 'bbb'}}
    keys={[
        {
            aaa: "zjtest002",
            bbb: "zjtest002测试",
        },
    ]}
*   @param getPeopleCode function(userKeyAndeName,userKeys) 会在弹窗点击确定时调用的回调函数 组件会给回调函数传入参数 *   参数为 userKeyAndeName, userKeys（不绑定onOk）
*  
*   暴露方法及返回值(与传入无关)
*   @param getPeopleCode 暴露方法 getPeopleCode，当通过暴露子组件本身时 父组件可以调用该方法获取返回值

*   返回值示例：
    {
        userKeys: ['code1','code2','code3','code4']
        userKeyAndName: [
            {
                userCode: "zjtest002",
                userName: "zjtest002测试",
            },
        ]
    }
    // 如果传入keyNames则userKeyAndName中的userCode和userName会变成传入时的命名
    更新：2020/09/02 现在选中两边的树可以同时进行操作
*/
import React, { PureComponent } from "react";
import { Tabs, Row, Col, Tree, message, Icon, Input, Table } from "antd";
import PublicServer from "./publicServer";
import { filterTreeData } from "yss-trade-base";
import {
    setColumns,
    withRoleTableBotton,
} from "yss-trade-base";
import "./index.less";
import { set } from "immutable";
const { TabPane } = Tabs;
const { DirectoryTree } = Tree;
class PeopleCode extends PureComponent {
    constructor(props) {
        super(props);
        this.props.refs && this.props.refs(this)
        this.API = new PublicServer();
        this.state = {
            orgTreeData: [], // 组织机构树
            userTreeData: [], // 用户角色树
            searchName: null, // 搜索
            treeData: [], // 当前打开的树
            checkedKeys: [], // 全部的选中值
            userKeyAndName: [], // 全部的选中值的table渲染
            expandedKeys: [], // 全部的展开值
            total: 0, // 总数
            checkedOrg: [], // 机构树选中值
            checkedRole: [], // 用户树选中值
            nowTab: '1',
            allOrgKeys: [], // 组织机构树中所有的keys
            allRoleKeys: [], // 用户角色树中所有的keys
        };
    }
    componentDidMount() {
        this.props.onRef(this);
        const keys = this.props.keys || []
        // 表格选中值处理 树的选中值需要先获取树结构才能初始化
        this.setState({
            userKeyAndName: keys,
            total: keys.length,
            nowTab: this.props.defaultActiveKey || '1'
        })
        this.getOrgUserTree();
        this.getRoleUserTree();
    }
    // 获取机构用户树
    getOrgUserTree = () => {
        this.API.getOrgUserTree().then((res) => {
            // console.log(res);
            if (res.code !== "200") {
                message.error(res.msg);
                return false;
            }
            let data = res.data;
            let filterValue = this.state.searchName;
            filterValue = filterValue !== null ? { filterValue } : {};
            // 改变结构
            let treeData = filterTreeData(data || [], {
                keyField: "treeCode",
                titleField: "treeName",
                filterValue: "",
                treeNodeRender: (node) => {
                    //是否为子节点
                    return {
                        key: `${node.treeCode}`,
                        title: <span className="tree-title">{node.treeName}</span>,
                        icon: node.type === "USER" ? <Icon type="user" /> : <Icon type="team" />,
                    };
                },
            });
            // console.log(treeData);
            const deep = this.props.deep || false
            if (deep) {
                treeData.rows = this.deepControl(treeData.rows, deep)
                console.log(treeData.rows)
            }
            const allOrgKeys = treeData.keys // 获取所有左边树的编码

            let expandedKeys = new Set([]);
            let checkedKeys = this.getCodes(this.props.keys); // 获取选中的所有用户编码
            let checkedOrg = []
            const defaultActiveKey = this.props.defaultActiveKey || "1";
            if (checkedKeys) {
                checkedKeys.forEach((item) => {
                    // 需要选中的树节点
                    checkedOrg = checkedOrg.concat(this.selectTreeCode(item, treeData.rows))
                });
                if (defaultActiveKey === '2') {
                    // 如果有传入选中值
                    checkedKeys.forEach((item) => {
                        // 获取需要展开的父节点
                        const one = this.getParentKey(item, treeData.rows);
                        expandedKeys.add(one); // 过滤去重添加
                    });
                }
            }
            expandedKeys = [...expandedKeys]; // 重新转为数组
            checkedOrg = new Set(checkedOrg)
            checkedOrg = [...checkedOrg]
            checkedOrg = this.getTreeTypeUser(checkedOrg, treeData.rows)
            console.log(checkedOrg)
            if (defaultActiveKey === "1") {
                this.setState({
                    orgTreeData: treeData.rows,
                    treeData: treeData.rows,
                    checkedKeys: checkedKeys, // 所有选中值
                    checkedOrg: checkedOrg, // ORG选中值
                    expandedKeys: expandedKeys,
                    allOrgKeys: allOrgKeys
                });
            } else {
                this.setState({
                    orgTreeData: treeData.rows,
                    checkedOrg: checkedOrg, // ORG选中值
                    allOrgKeys: allOrgKeys
                });
            }
        });
    };

    // 获取角色用户树
    getRoleUserTree = () => {
        this.API.getRoleUserTree().then((res) => {
            // console.log(res);
            if (res.code !== "200") {
                message.error(res.msg);
                return false;
            }
            let data = res.data;
            let filterValue = this.state.searchName;
            filterValue = filterValue !== null ? { filterValue } : {};
            // 改变结构
            let treeData = filterTreeData(data || [], {
                keyField: "treeCode",
                titleField: "treeName",
                filterValue: "",
                treeNodeRender: (node) => {
                    //是否为子节点
                    return {
                        key: `${node.treeCode}`,
                        title: <span className="tree-title">{node.treeName}</span>,
                        icon: node.type === "USER" ? <Icon type="user" /> : <Icon type="team" />,
                    };
                },
            });

            const deep = this.props.deep || false
            if (deep) {
                treeData.rows = this.deepControl(treeData.rows, deep)
                console.log(treeData.rows)
            }
            const allRoleKeys = treeData.keys // 获取所有右边树的编码

            let expandedKeys = new Set([]);
            let checkedKeys = this.getCodes(this.props.keys); // 获取选中的所有编码
            let checkedRole = []
            const defaultActiveKey = this.props.defaultActiveKey || "1";
            if (checkedKeys) {
                checkedKeys.forEach((item) => {
                    // 需要选中的树节点
                    checkedRole = checkedRole.concat(this.selectTreeCode(item, treeData.rows))
                });
                if (defaultActiveKey === '2') {
                    // 如果有传入选中值
                    checkedKeys.forEach((item) => {
                        // 获取需要展开的父节点
                        const one = this.getParentKey(item, treeData.rows);
                        expandedKeys.add(one); // 过滤去重添加
                    });
                }
            }
            expandedKeys = [...expandedKeys]; // 重新转为数组
            checkedRole = new Set(checkedRole)
            checkedRole = [...checkedRole]
            checkedRole = this.getTreeTypeUser(checkedRole, treeData.rows)
            console.log(checkedRole)
            if (defaultActiveKey === "2") {
                this.setState({
                    userTreeData: treeData.rows,
                    treeData: treeData.rows,
                    checkedKeys: checkedKeys, // 所有选中值
                    checkedRole: checkedRole, // user选中值
                    expandedKeys: expandedKeys,
                    allRoleKeys: allRoleKeys
                });
            } else {
                this.setState({
                    userTreeData: treeData.rows,
                    checkedRole: checkedRole, // user选中值
                    allRoleKeys: allRoleKeys
                });
            }
        });
    };

    // 获取选中值keys(treecodes)
    getCodes = (arr) => {
        const names = this.props.keyNames || { 'key': 'userCode', 'name': 'userName' }
        // console.log(arr, names)
        if (!arr || arr.length === 0) {
            return []
        }
        if (!arr[0][names.key]) {
            return arr
        }
        const keys = []
        arr.forEach(item => {
            const one = item[names.key]
            keys.push(one)
        })
        console.log(names.key, keys)
        return keys
    }

    // 获取父节点treeCode
    getParentKey = (key, tree) => {
        let parentKey;
        for (let i = 0; i < tree.length; i++) {
            const node = tree[i];
            if (node.children) {
                if (node.children.some((item) => item.key === key)) {
                    parentKey = node.key;
                } else if (this.getParentKey(key, node.children)) {
                    parentKey = this.getParentKey(key, node.children);
                }
            }
        }
        return parentKey;
    };
    // 过滤非角色节点
    filterParentKey = (key, tree) => {
        const names = this.props.keyNames || { 'key': 'userCode', 'name': 'userName' }
        let user = {
            flag: false,
            keyAndName: {},
            key: '',
        };
        for (let i = 0; i < tree.length; i++) {
            const node = tree[i];
            if (!node.children || node.children === null) {
                // 如果不存在子节点
                if (node.key === key && node.type === "USER") { // 为USE的节点都具有userCode
                    user.flag = true;
                    user.key = node.userCode
                    user.keyAndName = {
                        [names.key]: node.userCode,
                        [names.name]: node.treeName,
                    }
                }
            } else if ((this.filterParentKey(key, node.children)).flag) {
                user = this.filterParentKey(key, node.children);
            }
        }
        return user;
    };
    // 过滤非角色节点并返回树节点
    filterParentKeyTreeCode = (key, tree) => {
        let user = {
            flag: false,
            key: '',
        };
        for (let i = 0; i < tree.length; i++) {
            const node = tree[i];
            if (!node.children || node.children === null) {
                // 如果不存在子节点
                if (node.key === key && node.type === "USER") { // 为USE的节点都具有userCode
                    user.flag = true;
                    user.key = node.treeCode
                }
            } else if ((this.filterParentKeyTreeCode(key, node.children)).flag) {
                user = this.filterParentKeyTreeCode(key, node.children);
            }
        }
        return user;
    };
    // 筛选相同userCode节点的treeCode 通过用户code筛选treeCode
    selectTreeCode = (key, tree) => {
        let values = [];
        let object = '';
        tree.forEach(item => {
            const tmp = {...item}
            if (tmp.userCode) {
                if (tmp.userCode === key) {
                    object = tmp.treeCode
                }
            } else{
                if (tmp.children) {
                    values = values.concat(this.selectTreeCode(key, tmp.children))
                }
            }
            if (object) {
                values.push(object)
            }
        })
        return values
    }

    // 比较两个数组的相同值并取出组成一个新数组
    compareArray = (array1, array2) => {
        const o = [];//临时对象o
        const tempArray = [];//临时数组

        for (let i = 0; i < array1.length; i++) {
            o[array1[i]] = true;// 将数array1 中的元素值作为对象o中的键，值为true；
        }

        for (let j = 0; j < array2.length; j++) {
            if (o[array2[j]]) {
                tempArray.push(array2[j]);//过滤array1 中与array2 相同的元素；
            }
        }
        return tempArray
    }
    // 比较两个数组的值并取非相同值组成一个新数组
    compareArrayDiff = (array1, array2) => {
        return array1.concat(array2).filter(function (v, i, arr) {
            return arr.indexOf(v) === arr.lastIndexOf(v);
        });
    }

    // 删除两表中指定用户id的treeCode
    delTreeCodeByUserCode = (code) => {
        const { orgTreeData, userTreeData } = this.state;
        let { checkedOrg, checkedRole } = this.state;
        let sameCode = this.selectTreeCode(code, orgTreeData)
        sameCode = sameCode.concat(this.selectTreeCode(code, userTreeData))
        sameCode = new Set(sameCode)
        sameCode = [...sameCode]
        checkedOrg = checkedOrg.filter(item => {
            return !sameCode.includes(item)
        })
        checkedRole = checkedRole.filter(item => {
            return !sameCode.includes(item)
        })
        this.setState({
            checkedOrg: checkedOrg,
            checkedRole: checkedRole
        })
    }

    /* 按钮组 */
    render() {
        const { treeData, expandedKeys, userKeyAndName, total, checkedRole, checkedOrg, orgTreeData, userTreeData } = this.state;
        const defaultActiveKey = this.props.defaultActiveKey || "1"; // 默认选则打开部门/岗位 也可以传入
        // console.log(treeData, checkedKeys, expandedKeys);
        /***表格行按钮组***/
        const names = this.props.keyNames || { 'key': 'userCode', 'name': 'userName' }
        const ButtonTableType = [
            {
                name: "删除",
                roule: true,
                func: this.deleteTableItem,
            }
        ];
        const tableColumns = [
            {
                title: "序号",
                dataIndex: "serialNumber",
                width: 260,
            },
        ];
        const formatColumns = setColumns(tableColumns);
        const columns = [
            ...formatColumns,
            {
                title: "员工姓名",
                width: 150,
                dataIndex: names.name,
                ellipsis: true,
            },
            {
                title: "操作",
                key: "operation",
                width: 150,
                align: "center",
                render: (row) => {
                    return withRoleTableBotton(ButtonTableType)(row);
                },
            },
        ];
        return (
            <div className="role-choose">
                <Row>
                    <Col span={8}>
                        <Tabs defaultActiveKey={defaultActiveKey} onTabClick={this.onTabClick} forceRender={false}>
                            <TabPane tab={"部门/岗位"} key="1">
                                <Input
                                    placeholder="请输入部门/岗位名称"
                                    onChange={this.onSearch}
                                    style={{ width: "100%", margin: "16px 0 16px 0" }}
                                />
                                <DirectoryTree
                                    multiple
                                    checkable
                                    onCheck={this.onCheck}
                                    onExpand={this.onExpand}
                                    treeData={treeData}
                                    checkedKeys={checkedOrg}
                                    expandedKeys={expandedKeys}
                                ></DirectoryTree>
                            </TabPane>
                            <TabPane tab={"角色"} key="2">
                                <Input
                                    placeholder="请输入角色名称"
                                    onChange={this.onSearch}
                                    style={{ width: "100%", margin: "16px 0 16px 0" }}
                                />
                                <DirectoryTree
                                    multiple
                                    checkable
                                    onCheck={this.onCheck}
                                    onExpand={this.onExpand}
                                    treeData={treeData}
                                    checkedKeys={checkedRole}
                                    expandedKeys={expandedKeys}
                                ></DirectoryTree>
                            </TabPane>
                        </Tabs>
                    </Col>
                    <Col span={16}>
                        <div className="puc-table-box">
                            <div className="puc-table-box-title">
                                <div className="box-title-d1">已选配置人员</div>
                                <div className="box-title-d2">
                                    已选：<span style={{ color: "#ff900d" }}>{total}</span>人
                                </div>
                            </div>
                            <div className="puc-table-content">
                                <Table
                                    scroll={{ y: 500 }}
                                    pagination={false}
                                    {...{
                                        columns,
                                        dataSource: userKeyAndName,
                                        rowKey: names.key,
                                        height: 500,
                                    }}
                                />
                            </div>
                        </div>
                    </Col>
                </Row>
            </div>
        );
    }
    // 页面操作
    // 从表格中删除选中数据
    deleteTableItem = (e, item) => {
        const names = this.props.keyNames || { 'key': 'userCode', 'name': 'userName' }
        let { checkedKeys, userKeyAndName } = this.state
        // console.log(checkedKeys, userKeyAndName, item)
        const code = item[names.key]
        checkedKeys = checkedKeys.filter((item) => {
            return item !== code;
        })
        userKeyAndName = userKeyAndName.filter((item) => {
            // console.log(item[names.key])
            return item[names.key] !== code;
        })
        // console.log(checkedKeys, userKeyAndName)
        this.setState({
            checkedKeys: checkedKeys,
            userKeyAndName: userKeyAndName,
            total: userKeyAndName.length
        })
        this.delTreeCodeByUserCode(code)
    }
    // 树结构深度控制
    deepControl = (arr, deep, nowDeep) => {
        nowDeep = nowDeep || 1
        // 终止递归条件
        if (nowDeep > deep) {
            return null
        }
        let newArr = arr.map(item => {
            return {
                key: item.treeCode,
                title: item.TreeName,
                type: item.type
            }
        })
        nowDeep++
        for (const i in arr) {
            if (arr[i].children) { // 如果存在下级节点则deep增加一层
                newArr[i].children = this.deepControl(arr[i].children, deep, nowDeep)
            }
        }
        return newArr
    }

    // tab切换
    onTabClick = (item) => {
        const { orgTreeData, userTreeData } = this.state;
        if (item === "1") {
            this.setState({
                treeData: orgTreeData,
                nowTab: '1'
            });
        } else {
            this.setState({
                treeData: userTreeData,
                nowTab: '2'
            });
        }
    };
    // 展开和选中
    onCheck = (item) => {
        // 处理选中值中的非角色节点并且全部去除
        const { nowTab, userTreeData, orgTreeData } = this.state
        let { checkedRole, checkedOrg, } = this.state
        let nowChecked = nowTab === '1' ? checkedOrg : checkedRole
        let nowTree = nowTab === '1' ? orgTreeData : userTreeData
        item = this.getTreeTypeUser(item, nowTree)
        let diffKeys = this.compareArrayDiff(item, nowChecked) // 当前发生更变的树节点
        let changeUserKeys = [] // 当前发生更变的用户编码
        let orgSameCode = [] // 组织/架构 通过变动的用户编码获取到的treeCode
        let roleSameCode = [] // 角色 通过变动的用户编码获取到的treeCode
        if (nowTab === '1') {
            changeUserKeys = this.getUserKeys(diffKeys, '1') // 当前组织/架构发生更变

        } else{
            changeUserKeys = this.getUserKeys(diffKeys, '2') // 当前角色 发生更变
        }
        changeUserKeys.forEach(code => { // 通过用户编码获取到两树中发生变更的treeCode
            orgSameCode = orgSameCode.concat(this.selectTreeCode(code, orgTreeData))
            roleSameCode = roleSameCode.concat(this.selectTreeCode(code, userTreeData))
        })
        // orgSameCode = new Set(orgSameCode)
        // orgSameCode = [...orgSameCode]
        // roleSameCode = new Set(roleSameCode)
        // roleSameCode = [...roleSameCode]

        console.log(`发生变化diffKeys: ${diffKeys}`)
        console.log(`发生变化用户编码userKeys: ${changeUserKeys}`)
        console.log(`发生变化树编码orgSameCode: ${orgSameCode}`)
        console.log(`发生变化树编码roleSameCode: ${roleSameCode}`)
        const flag = item.length > nowChecked.length ? '添加' : '删除'
        console.log(flag)
        if (flag === '添加') {
            checkedOrg = checkedOrg.concat(orgSameCode)
            checkedOrg = new Set(checkedOrg)
            checkedOrg = [...checkedOrg]

            checkedRole = checkedRole.concat(roleSameCode)
            checkedRole = new Set(checkedRole)
            checkedRole = [...checkedRole]
        }
        if (flag === '删除') {
            checkedOrg = checkedOrg.filter(item => {
                return !orgSameCode.includes(item)
            })
            checkedRole = checkedRole.filter(item => {
                return !roleSameCode.includes(item)
            })
        }
        let allSelectedTreeCode = checkedOrg.concat(checkedRole) // 两颗树中所有选中的treeCode
        allSelectedTreeCode = new set(allSelectedTreeCode)
        allSelectedTreeCode = [...allSelectedTreeCode]
        const { userKeyAndName, userKeys } = this.getOutData(allSelectedTreeCode) // 通过treeCode整理数据
        this.setState({
            checkedKeys: userKeys,
            userKeyAndName: userKeyAndName,
            total: userKeyAndName.length,
            checkedRole: checkedRole,
            checkedOrg: checkedOrg
        })
    };
    onExpand = (item, obj) => {
        // console.log(item, obj)
        let setExpandKeys = []
        setExpandKeys = item
        this.setState({
            expandedKeys: setExpandKeys,
        });
    };
    heightLight = (nodeName, searchValue) => {
        // 定义搜索高亮
        const index = nodeName.indexOf(searchValue);
        const beforeStr = nodeName.substr(0, index);
        const afterStr = nodeName.substr(index + searchValue.length);
        const title =
            index > -1 ? (
                <span>
                    {beforeStr}
                    <span style={{ color: "#ff900d" }}>{searchValue}</span>
                    {afterStr}
                </span>
            ) : (
                    <span>{nodeName}</span>
                );
        return title;
    };
    // 筛选查找
    onSearch = (e) => {
        const value = e.target.value;
        const { orgTreeData, userTreeData, nowTab } = this.state;
        let TreeData = nowTab === '1' ? orgTreeData : userTreeData
        // 改变结构
        let treeData = filterTreeData(TreeData || [], {
            keyField: "treeCode",
            titleField: "treeName",
            filterValue: value,
            treeNodeRender: (node) => {
                //是否为子节点
                return {
                    key: `${node.treeCode}`,
                    title: <span className="tree-title">{this.heightLight(node.treeName, value)}</span>,
                    icon: node.type === "USER" ? <Icon type="user" /> : <Icon type="team" />,
                };
            },
        });
        let expandedKeys = new Set([]);
        let findeKeys = treeData.keys || [];
        if (findeKeys) {
            findeKeys.forEach((item) => {
                // 获取需要展开的父节点
                const one = this.getParentKey(item, treeData.rows);
                expandedKeys.add(one); // 过滤去重添加
            });
            expandedKeys = [...expandedKeys]; // 重新转为数组
        }
        if (!value) {
            expandedKeys = []
        }
        this.setState({
            treeData: treeData.rows,
            expandedKeys: expandedKeys,
        });
    };

    // 整理需要传出的数据
    // 为了方便使用本组件会返回一个对象 对象中有两个数组一个是纯keys的数组 另外一个是name和key共同的数组
    getOutData = (checkedKeys) => {
        const { orgTreeData, userTreeData } = this.state;
        const names = this.props.keyNames || { 'key': 'userCode', 'name': 'userName' }
        let userKeys1 = [];
        let userKeyAndName1 = [];
        let userKeys2 = [];
        let userKeyAndName2 = [];
        checkedKeys.forEach(item => {
            const user = this.filterParentKey(item, orgTreeData)
            if (user.flag) {
                userKeys1.push(user.key);
                userKeyAndName1.push(user.keyAndName)
            }
        });
        checkedKeys.forEach(item => {
            const user = this.filterParentKey(item, userTreeData)
            if (user.flag) {
                userKeys2.push(user.key);
                userKeyAndName2.push(user.keyAndName)
            }
        });
        const [...userKeys] = new Set(userKeys1.concat(userKeys2))
        // 对象数组不能使用set去重
        let arr = userKeyAndName1.concat(userKeyAndName2)
        const userKeyAndName = arr.filter(function (element, index, self) { return self.findIndex(el => el[names.key] === element[names.key]) === index })

        // console.log(`userKeys1: ${userKeys1} userKeyAndName1: ${userKeyAndName1} userKeys2: ${userKeys2} userKeyAndName2: ${userKeyAndName2} userKeys: ${userKeys} userKeyAndName:${userKeyAndName}`)
        return {
            userKeys: userKeys,
            userKeyAndName: userKeyAndName
        }
    }
    // 通过树节点获取指定树下的用户节点
    getUserKeys = (keys, nowTab) => {
        const { orgTreeData, userTreeData } = this.state;
        const treeData = nowTab === '1' ? orgTreeData : userTreeData
        let userKeys = [];
        keys.forEach(item => {
            const user = this.filterParentKey(item, treeData)
            if (user.flag) {
                userKeys.push(user.key);
            }
        });
        const [...newUserKeys] = new Set(userKeys)
        return newUserKeys
    }

    // 树节点 过滤掉非用户的树节点
    getTreeUserKeys = (checkedKeys, nowTab) => {
        const { orgTreeData, userTreeData } = this.state;
        const treeData = nowTab === '1' ? orgTreeData : userTreeData
        let userKeys = [];
        checkedKeys.forEach(item => {
            const user = this.filterParentKeyTreeCode(item, treeData)
            if (user.flag) {
                userKeys.push(user.key);
            }
        });
        const [...newUserKeys] = new Set(userKeys)
        return newUserKeys
    }

    getTreeTypeUser = (checkedKeys, treeData) => {
        let userKeys = [];
        checkedKeys.forEach(item => {
            const user = this.filterParentKeyTreeCode(item, treeData)
            if (user.flag) {
                userKeys.push(user.key);
            }
        });
        const [...newUserKeys] = new Set(userKeys)
        return newUserKeys
    }

    // 点击确定获取数据
    async handleSubmit(e) {
        const { checkedKeys, userKeyAndName } = this.state;
        const getPeopleCode = this.props.getPeopleCode
        console.log(checkedKeys, userKeyAndName)
        if (getPeopleCode) {
            getPeopleCode(userKeyAndName, checkedKeys)
        }
        // console.log(userKeyAndName, userKeys)
    }

    // 返回选中值的keys数组和渲染用数组
    getPeopleCode = () => {
        const { checkedKeys, userKeyAndName } = this.state;
        return {
            userKeys: checkedKeys,
            userKeyAndName: userKeyAndName
        }
    }
}

export default PeopleCode;
