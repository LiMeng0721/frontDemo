/**
 * 当期项目公共组件使用的接口
 */
import { service } from "win-trade-base";
const dfasUserRole = "/dfas-auth-center";
export default class PublicServese {
    // 角色用户树结构
    getRoleUserTree(params) {
        return service.httpService({
            baseURL: dfasUserRole,
            url: "/userRole/getRoleUserTree",
            method: "post",
            data: params
        });
    }
    // 机构用户树
    getOrgUserTree(params) {
        return service.httpService({
            baseURL: dfasUserRole,
            url: "/userOrg/getOrgUserTree",
            method: "post",
            data: params
        });
    }
}
